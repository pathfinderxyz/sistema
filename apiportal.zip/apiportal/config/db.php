
<?php
    class DB{
        // Properties
        private $dbhost = 'localhost';
        private $dbuser = 'u146548383_portal';
        private $dbpass = 'Eris$$22';
        private $dbname = 'u146548383_portal';

        // Connect
        public function connect(){
            $conn_str = "mysql:host=$this->dbhost;dbname=$this->dbname";
            $conn = new PDO($conn_str, $this->dbuser, $this->dbpass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        }
}

$link = mysqli_connect("localhost", "u146548383_portal", "Eris$$22", "u146548383_portal");