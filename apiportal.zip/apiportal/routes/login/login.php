<?php

/////////////////////login/////////////////////////////////
$app->post('/login', function ($request, $response, array $args) {
    $params = (array)$request->getParsedBody();

    $usuario = $params['email'];
    $clave = $params['password'];

    // Consultar en la tabla alumnos
    $sql1 = "SELECT * FROM alumnos WHERE UPPER(correo) = UPPER(:usuario) AND clave = :clave";
    $db1 = new DB();
    $conn1 = $db1->connect();
    $stmt1 = $conn1->prepare($sql1);
    $stmt1->bindParam(':usuario', $usuario);
    $stmt1->bindParam(':clave', $clave);
    $stmt1->execute();
    $data1 = $stmt1->fetchAll(PDO::FETCH_OBJ);

    // Si no se encuentra en la tabla alumnos, consultar en la tabla profesores
    if (!$data1) {
        $sql2 = "SELECT * FROM profesores WHERE UPPER(correo) = UPPER(:usuario) AND clave = :clave";
        $stmt2 = $conn1->prepare($sql2);
        $stmt2->bindParam(':usuario', $usuario);
        $stmt2->bindParam(':clave', $clave);
        $stmt2->execute();
        $data2 = $stmt2->fetchAll(PDO::FETCH_OBJ);

        if ($data2) {
            $response->getBody()->write(json_encode($data2));
            return $response
                ->withHeader('content-type', 'application/json')
                ->withStatus(200);
        }
    } else {
        $response->getBody()->write(json_encode($data1));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(200);
    }

    // Si no se encuentra en ninguna tabla, devolver un error
    $data3 = [
        'conectado' => false,
        'error' => 'Los datos son incorrectos, vuelva a intentarlo'
    ];
    $response->getBody()->write(json_encode($data3));
    return $response
        ->withHeader('content-type', 'application/json')
        ->withStatus(200);
});

$app->post('/logininicial', function ($request,$response,array $args) {
    $params = (array)$request->getParsedBody();

    $usuario = $params['usuario'];
    $clave = $params['clave'];

    $sql1="select * from usuarios where UPPER(correo)=UPPER('$usuario') AND clave='$clave'";
    $db1=new DB();
    $conn1= $db1->connect();
    $stmt1=$conn1->query($sql1);
    $data1=$stmt1->fetchAll(PDO::FETCH_OBJ);


     if($data1){
         
        $db=null;
        $response->getBody()->write(json_encode($data1));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

        } else {
            $data3[]=array(
                'conectado'=>false, 
                'error' => 'La datos son incorrecto, vuelva a intentarlo'
                );
            $response->getBody()->write(json_encode($data3));
            return $response
                ->withHeader('content-type','application-json')
                ->withStatus(200);
        }
       
});


$app->post('/registrarusuario', function ($request, $response, array $args) {
    $params = (array)$request->getParsedBody();

    // Mapeo de campos del formulario React
    $nombre = $params['nombre'];
    $correo = $params['correo'];
    $clave = $params['clave'];
    $telefono = $params['telefono'];
    $rol = $params['rol'] ?? 'usuario'; // Valor por defecto si no viene
    $status = $params['status'] ?? 'activo'; // Valor por defecto si no viene


    // Verificar si el correo ya existe
    $sqlCheck = "SELECT * FROM usuarios WHERE correo = :correo";
    $dbCheck = new DB();
    $connCheck = $dbCheck->connect();
    $stmtCheck = $connCheck->prepare($sqlCheck);
    $stmtCheck->bindParam(':correo', $correo);
    $stmtCheck->execute();
    $existingUser = $stmtCheck->fetch();

    if ($existingUser) {
        return $response->withJson(['error' => 'El correo electrónico ya está registrado'], 409);
    }

    // Insertar nuevo usuario
    $sqlInsert = "INSERT INTO usuarios 
                 (nombre, correo, clave, telefono, rol, status, fecha_creacion) 
                 VALUES 
                 (:nombre, :correo, :clave, :telefono, :rol, :status, NOW())";

    $dbInsert = new DB();
    $connInsert = $dbInsert->connect();


    $stmtInsert = $connInsert->prepare($sqlInsert);
    
    $stmtInsert->bindParam(':nombre', $nombre);
    $stmtInsert->bindParam(':correo', $correo);
    $stmtInsert->bindParam(':clave', $clave);
    $stmtInsert->bindParam(':telefono', $telefono);
    $stmtInsert->bindParam(':rol', $rol);
    $stmtInsert->bindParam(':status', $status);

    $result = $stmtInsert->execute();

    if ($result) {
        return $response->withJson([
            'success' => true,
            'message' => 'Usuario registrado exitosamente',
            'data' => [
                'nombre' => $nombre,
                'correo' => $correo,
                'rol' => $rol,
                'status' => $status
            ]
        ], 201);
    } else {
        return $response->withJson([
            'error' => 'Error al registrar el usuario',
            'details' => $connInsert->errorInfo()
        ], 500);
    }
});



?>





















