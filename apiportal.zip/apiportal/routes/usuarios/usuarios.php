<?php

/////////////////////////ciudades///////////////////////////////////////////////////////////////////////////////
$app->get('/usuarios', function ($request,$response) {

    $sql="SELECT * from usuarios";

    try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->query($sql);
        $ciudades=$stmt->fetchAll(PDO::FETCH_OBJ);

        $db=null;
        $response->getBody()->write(json_encode($ciudades));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
   
});

$app->get('/clientes', function ($request,$response) {

    $sql="SELECT * from clientes";

    try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->query($sql);
        $ciudades=$stmt->fetchAll(PDO::FETCH_OBJ);

        $db=null;
        $response->getBody()->write(json_encode($ciudades));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
   
});



$app->get('/usuarioscantidad', function ($request,$response) {

    $sql="SELECT * from CANTIDAD_USUARIOS";

    try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->query($sql);
        $ciudades=$stmt->fetchAll(PDO::FETCH_OBJ);

        $db=null;
        $response->getBody()->write(json_encode($ciudades));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
   
});

$app->get('/usuariospanel', function ($request,$response) {

    $sql="SELECT * from userpanel";

    try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->query($sql);
        $ciudades=$stmt->fetchAll(PDO::FETCH_OBJ);

        $db=null;
        $response->getBody()->write(json_encode($ciudades));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
   
});

$app->put('/usuariospanel/{id}', function ($request,$response,array $args) {
    $params = (array)$request->getParsedBody();

    $id = $args['id'];
    $rol = $params['rol'];
          
        $sql="UPDATE userpanel SET rol= :rol WHERE id =:id";
        
        try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->prepare($sql);
        $stmt->bindParam(':id',$id);
        $stmt->bindParam(':rol',$rol);
        
        $plan=$stmt->execute();
        
        $response->getBody()->write(json_encode($plan));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
        
});

$app->get('/usuarios/{id}', function ($request,$response,array $args) {

    $id = $args['id'];

    $sql="SELECT * from usuarios where id=$id";

    try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->query($sql);
        $user=$stmt->fetchAll(PDO::FETCH_OBJ);

        $db=null;
        $response->getBody()->write(json_encode($user));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
   
});

$app->get('/clientes/{id}', function ($request,$response,array $args) {

    $id = $args['id'];

    $sql="SELECT * from clientes_final where usuario_id=$id";

    try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->query($sql);
        $user=$stmt->fetchAll(PDO::FETCH_OBJ);

        $db=null;
        $response->getBody()->write(json_encode($user));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
   
});

$app->get('/clientesemail/{id}', function ($request, $response, array $args) {
    $id = $args['id']; // Ejemplo: "usuario@gmail.com"

    // consulta segura con parámetros preparados
    $sql = "SELECT * FROM clientes_final WHERE email = :email";

    try {
        $db = new DB();
        $conn = $db->connect();

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $id); // Escapa automáticamente el valor
        $stmt->execute();
        $user = $stmt->fetchAll(PDO::FETCH_OBJ);

        $db = null;
        $response->getBody()->write(json_encode($user));
        return $response
            ->withHeader('content-type', 'application/json') // Corrección: "application/json"
            ->withStatus(200);

    } catch (PDOException $e) {
        $error = array("message" => $e->getMessage());
        $response->getBody()->write(json_encode($error));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(500);
    }
});



$app->get('/usuariolanding/{usuario}', function ($request, $response, array $args) {
    
    $usuario = $args['usuario'];

    $sql = "SELECT * FROM usuarios WHERE usuario = :usuario";

    try {
        $db = new DB();
        $conn = $db->connect();

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->execute();
        $user = $stmt->fetchAll(PDO::FETCH_OBJ);

        $db = null;
        $response->getBody()->write(json_encode($user));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error = array(
            "message" => $e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(500);
    }
});

$app->get('/usuarioexiste/{usuario}', function ($request, $response, array $args) {
    $usuario = $args['usuario'];
    
    $sql = "SELECT COUNT(*) AS count FROM usuarios WHERE usuario = :usuario"; // Contamos si existe el usuario
    try {
        $db = new DB();
        $conn = $db->connect();
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC); // Obtenemos el resultado como un array asociativo
        $db = null;

        // Verificamos si el conteo es mayor a 0 (existe el usuario)
        $exists = $result['count'] > 0;

        // Devolvemos true o false en formato JSON
        $response->getBody()->write(json_encode($exists));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(200);
    } catch (PDOException $e) {
        $error = array(
            "message" => $e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(500);
    }
});


$app->post('/register', function ($request, $response, array $args) {
    $params = (array)$request->getParsedBody();
    
    $nombre = $params['nombre'];
    $correo = $params['correo'];
    $clave = $params['clave'];
    $telefono = $params['telefono'];
    $rol = 'cliente'; // Valor por defecto
    $status = 'activo'; // Valor por defecto

    $sql1 = "SELECT * FROM usuarios WHERE UPPER(correo) = UPPER(:correo)";
    $db1 = new DB();
    $conn1 = $db1->connect();
    $stmt1 = $conn1->prepare($sql1);
    $stmt1->bindParam(':correo', $correo);
    $stmt1->execute();
    $data1 = $stmt1->fetchAll();

    if (!$data1) {
        $sql = "INSERT INTO usuarios (nombre, correo, clave, telefono, rol, status) VALUES 
        (:nombre, :correo, :clave, :telefono, :rol, :status)";
        $db = new DB();
        $conn = $db->connect();

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':correo', $correo);
        $stmt->bindParam(':clave', $clave);
        $stmt->bindParam(':telefono', $telefono);
        $stmt->bindParam(':rol', $rol);
        $stmt->bindParam(':status', $status);

        $result = $stmt->execute();

        $response->getBody()->write(json_encode($result));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(200);
    } else {
        $data3[] = array("Result" => "Error el correo ya existe");
        $response->getBody()->write(json_encode($data3));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(500);
    }
});


$app->put('/usuarios/{id}', function ($request,$response,array $args) {
    $params = (array)$request->getParsedBody();

    $id = $args['id'];
    $nombre = $params['nombre'];
    $correo = $params['correo'];
    $telefono = $params['telefono'];
    $clave = $params['clave'];
    $status = $params['status'];
    
        $sql="UPDATE usuarios SET nombre=:nombre,correo=:correo,telefono=:telefono,clave=:clave,status=:status WHERE id =:id";
        
        try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->prepare($sql);
        $stmt->bindParam(':id',$id);
        $stmt->bindParam(':nombre',$nombre);
        $stmt->bindParam(':correo',$correo);
        $stmt->bindParam(':telefono',$telefono);
        $stmt->bindParam(':clave',$clave);
        $stmt->bindParam(':status',$status);
        $roles=$stmt->execute();
        
        $response->getBody()->write(json_encode($roles));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
        
});




$app->DELETE('/usuariosdelete/{id}', function ($request,$response,array $args) {
    $params = (array)$request->getParsedBody();

    $id = $args['id'];
    
        $sql="DELETE FROM usuarios WHERE id =:id";
        
        try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->prepare($sql);
        $stmt->bindParam(':id',$id);
        
        $roles=$stmt->execute();
        
        $response->getBody()->write(json_encode($roles));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
        
});


$app->put('/usuariosedit/{id}', function ($request, $response, array $args) {
    $params = (array)$request->getParsedBody();

    $id = $args['id'];
    $status = $params['status'];
    $fecha = date("Y-m-d"); 

    $sql = "UPDATE documentos SET 
                status = :status,
                fecha = :fecha
            WHERE id = :id";

    try {
        $db = new DB();
        $conn = $db->connect();

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':fecha', $fecha);

        $roles = $stmt->execute();

        $response->getBody()->write(json_encode($roles));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error = array(
            "message" => $e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
            ->withHeader('content-type', 'application/json')
            ->withStatus(500);
    }
});

$app->put('/usuarioclave/{id}', function ($request,$response,array $args) {
    $params = (array)$request->getParsedBody();

    $id = $args['id'];
    $clave = $params['pass'];
   
          
         $sql="UPDATE usuarios SET password=:clave WHERE id =:id";
        
        try {
        $db=new DB();
        $conn= $db->connect();

        $stmt=$conn->prepare($sql);
        $stmt->bindParam(':id',$id);
        $stmt->bindParam(':clave',$clave);
        
        $plan=$stmt->execute();
        
        $response->getBody()->write(json_encode($plan));
        return $response
            ->withHeader('content-type','application-json')
            ->withStatus(200);

    } catch (PDOException $e) {
        $error=array(
            "message" =>$e->getMessage()
        );
        $response->getBody()->write(json_encode($error));
        return $response
        ->withHeader('content-type','application-json')
        ->withStatus(500);
    }
        
});




?>